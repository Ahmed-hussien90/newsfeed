package com.example.newsfeed;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class NewsAdapter extends ArrayAdapter<News> {
    public NewsAdapter(Context context, List<News> news) {
        super(context, 0, news);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if there is an existing list item view (called convertView) that we can reuse,
        // otherwise, if convertView is null, then inflate a new list item layout.
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.newslist, parent, false);
        }

        News currentnews = getItem(position);

        TextView title = listItemView.findViewById(R.id.titlee);
        title.setText(currentnews.getWebTitle());

        TextView type = listItemView.findViewById(R.id.type);
        type.setText(currentnews.getType());

        TextView section = listItemView.findViewById(R.id.sectionname);
        section.setText(currentnews.getSectionName());

        TextView date = listItemView.findViewById(R.id.date);
        date.setText("Published At  "+currentnews.getWebPublicationDate());

        return listItemView;

}
}
