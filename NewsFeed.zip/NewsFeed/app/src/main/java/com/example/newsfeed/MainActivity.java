package com.example.newsfeed;

import androidx.appcompat.app.AppCompatActivity;

import android.app.LoaderManager;
import android.content.Intent;
import android.content.Loader;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<News>> {
    NewsAdapter ad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText editsearch = (EditText) findViewById(R.id.editSearch);
        Button ptnsearch = (Button) findViewById(R.id.btnSearch);
        ListView listView = (ListView) findViewById(R.id.list_item2);

        listView.setBackgroundColor(getResources().getColor(R.color.colorAccent));

        List<News> ar = new ArrayList<>();

         ad = new NewsAdapter(this, ar);

        listView.setAdapter(ad);
        ptnsearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("searchWord",editsearch.getText().toString());
                LoaderManager loaderManager = getLoaderManager();
                loaderManager.initLoader(1,bundle,MainActivity.this);
                loaderManager.restartLoader(1,bundle,MainActivity.this);
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                News currentnews = ad.getItem(position);
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(currentnews.getWebUrl()));
                startActivity(intent);
            }
        });    }
    @Override
    public Loader<List<News>> onCreateLoader(int id, Bundle args) {
        return new NewsLoader(this, "http://content.guardianapis.com/search?q="+args.getString("searchWord")+"&api-key=test");
    }

    @Override
    public void onLoadFinished(Loader<List<News>> loader, List<News> data) {
        ad.clear();

        // If there is a valid list of {@link Earthquake}s, then add them to the adapter's
        // data set. This will trigger the ListView to update.
        if (data != null && !data.isEmpty()) {
            ad.addAll(data);
        }

    }

    @Override
    public void onLoaderReset(Loader<List<News>> loader) {
      ad.clear();
    }
}