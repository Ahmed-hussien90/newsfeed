package com.example.newsfeed;

public class News {
    private String type;
    private String webPublicationDate;
    private String sectionName;
    private String webTitle;
    private String webUrl;

    public String getWebPublicationDate() {
        return webPublicationDate;
    }

    public News(String type, String webPublicationDate, String sectionName, String webTitle, String webUrl) {
        this.type = type;
        this.webPublicationDate = webPublicationDate;
        this.sectionName = sectionName;
        this.webTitle = webTitle;
        this.webUrl = webUrl;
    }

    public String getType() {
        return type;
    }

    public String getSectionName() {
        return sectionName;
    }

    public String getWebTitle() {
        return webTitle;
    }

    public String getWebUrl() {
        return webUrl;
    }
}
